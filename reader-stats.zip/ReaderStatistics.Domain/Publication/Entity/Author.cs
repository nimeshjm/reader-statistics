﻿using ReaderStatistics.Domain.Shared;

namespace ReaderStatistics.Domain.Publication.Entity
{
    public class Author : Person
    {
    }
}