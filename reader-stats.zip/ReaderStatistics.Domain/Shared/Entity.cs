﻿using System;

namespace ReaderStatistics.Domain.Shared
{
    public class Entity
    {
        public Guid Id { get; set; }
    }
}
