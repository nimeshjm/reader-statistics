﻿namespace ReaderStatistics.Domain.Shared
{
    public class Person : Entity
    {
        public string FirstName { get; set; }

        public string LastName { get; set; }
    }
}
