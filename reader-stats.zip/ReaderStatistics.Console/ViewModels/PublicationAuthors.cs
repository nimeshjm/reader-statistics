﻿using System.Collections.Generic;

namespace ReaderStatistics.Console.ViewModels
{
    public class PublicationAuthors
    {
        public string Name { get; set; }

        public int NumberOfViews { get; set; }

        public string Authors { get; set; }
    }
}
