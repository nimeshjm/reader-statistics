﻿namespace ReaderStatistics.Console.ViewModels
{
    public class UserAccess
    {
        public string Name { get; set; }

        public int NumberOfViews { get; set; }
    }
}